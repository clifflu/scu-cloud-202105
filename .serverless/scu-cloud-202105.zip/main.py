CATALOG = 'https://tcgbusfs.blob.core.windows.net/blobtcmsv/TCMSV_alldesc.json'
LIVE = 'https://tcgbusfs.blob.core.windows.net/blobtcmsv/TCMSV_allavailable.json'

interesting_ids = {
    # '079',
}

def main():
    pass


if __name__ == '__name__':
    main()
